import React,{Component} from 'react';
import axios from 'axios';

class EditUser extends Component{

    constructor(props){
        super(props);
        this.state=({
            firstname:'',
            lastname:'',
            username:'',
            email:'',
            dob:'',
            cpassword:'',
            password:'',
        });
    }

    componentDidMount()
    {
        console.log(this.props.match.params.id)
        axios.get(`http://localhost:4000/user/edit/${this.props.match.params.id}`)
        .then(res => {
            this.setState({
              firstname:res.data.firstname,
              lastname:res.data.lastname,
              email:res.data.email,
              dob:res.data.dob,
              cpassword:res.data.cpassword,
              username: res.data.username,
              password: res.data.password},()=>{ this.dateset()} );
        })
        .catch(error =>
            console.log(error));

    }

    dateset()
    {
        var today = new Date(this.state.dob);
        var dd = ("0" + today.getDate()).slice(-2);
        var mm = ("0" + (today.getMonth() + 1)).slice(-2);
        var yyyy = today.getFullYear();
        var setdate = yyyy+"-"+mm+"-"+dd;
        this.setState({dob: setdate})
    }

    handlechange=(e)=>{
        const{ name , value} = e.target;
        this.setState({[name] : value});
    }

    handlesubmit=async (e)=>{
        e.preventDefault();
        let data = this.state;
        console.log(this.state);
        await axios.post(`http://localhost:4000/user/update/${this.props.match.params.id}`, data)
            .then(res=>console.log(res.data));
        this.props.history.push('/');
    }

    render(){
        return(
            <div>
                <h3>Edit User</h3>
                <form name="editform" onSubmit={this.handlesubmit}>

                     <label>Firstname:</label>
                    <input type="text" name="firstname" value={this.state.firstname} 
                        onChange={this.handlechange} />
                    <br/><br/>

                     <label>Lastname:</label>
                    <input type="text" name="lastname" value={this.state.lastname} 
                        onChange={this.handlechange} />
                    <br/><br/>

                     <label>Username:</label>
                    <input type="text" name="username" value={this.state.username} 
                        onChange={this.handlechange} />
                    <br/><br/>

                     <label>Email:</label>
                    <input type="text" name="email" value={this.state.email} 
                        onChange={this.handlechange} />
                    <br/><br/>

                     <label>Date of Birth:</label>
                    <input type="date" name="dob" value={this.state.dob} id="datepicker" 
                        onChange={this.handlechange} />
                    <br/><br/>

                    <label>Password:</label>
                    <input type="password" name="password" value={this.state.password} 
                        onChange={this.handlechange} />
                    <br/><br/>

                    <label>Confirm Password:</label>
                    <input type="password" name="cpassword" value={this.state.cpassword}
                        onChange={this.handlechange} />
                    <br /><br />

                    {/* <label>Upload Image:</label>
                    <input type="file" name="file" value={this.state.file}
                        onChange={this.handlechange} />
                    <br /><br /> */}

                    <button>Update</button><br /><br />

                </form>
            </div>
        );
    }
}   

export default EditUser;