import React,{Component} from 'react';
import { kMaxLength } from 'buffer';

const validEmailRegex = RegExp(/\S+@\S+\.\S+/);
const validationForm=(errors)=>{
    let valid = true;
    Object.values(errors).forEach(
        (val) => val.length > 0 && (valid = false)
      );
      return valid;
}
const countErrors = (errors) => {
    let count = 0;
    Object.values(errors).forEach(
      (val) => val.length > 0 && (count = count+1)
    );
    return count;
  }

class Register extends Component{

    constructor(props){
        super(props);
        this.state={
            firstname:'',
            lastname:'',
            username:'',
            email:'',
            dob:'',
            password:'',
            cpassword:'',
            file:'',
            errors:{ firstname:'',lastname:'',username:'',email:'',password:''},
            formvalid:false,
            errorcount:''
        };
    }

    handleChange=(e)=>{
        const { name , value} = e.target;
        this.setState({[name]: value});
        let errors = this.state.errors;

        switch (name) {
            case 'firstname':
              errors.firstname = value.length < 5 ? 'Full Name must be 5 characters long!': '';
              break;
            case 'lastname': 
              errors.lastname = value.length < 5 ? 'Full Name must be 5 characters long!': '';
              break;
            case 'email': 
              errors.email = validEmailRegex.test(value) ? '' : 'Email is not valid!';
              break;
            case 'password': 
              errors.password = value.length < 8 ? 'Password must be 8 characters long!' : '';
              break;
            case 'username':
              errors.username = value.length < 6 ? 'Length must me 6':'';
              break;
            default:
              break;
          }
          this.setState({errors, [name]: value});
    }


    hadleSubmit=(e)=>{
        e.preventDefault();
        this.setState({formvalid: validationForm(this.state.errors)});
        this.setState({errorcount: countErrors(this.state.errors)});
    }


    render(){
        const {  errors,formvalid } = this.state;
        return(
            <div>
                <h4>Registration</h4>

            <form onSubmit={this.hadleSubmit} noValidate>

                <div className="form-group">
                    <label>Firstname:</label>
                    <input type="text" onChange={this.handleChange} className="form-control"
                        name="firstname" noValidate/>
                    { errors.firstname.length > 0 && 
                    <span className='error'>{errors.firstname}</span>}
                </div>

                <div className="form-group">
                    <label>Lastname:</label>
                    <input type="text" onChange={this.handleChange} className="form-control"
                        name="lastname" noValidate/>
                    { errors.lastname.length > 0 && 
                    <span className='error'>{errors.lastname}</span>}
                </div>


                <label>Username:</label>
                <input type="text" onChange={this.handleChange} 
                    name="username" noValidate/>
                { errors.username.length > 0 && 
                <span className='error'>{errors.username}</span>}<br/><br/>
   

                <label>Email:</label>
                <input type="text" onChange={this.handleChange} 
                    name="email" noValidate/>
                { errors.email.length > 0 && 
                <span className='error'>{errors.email}</span>}<br/><br/>
               

                <label>Date of Birth:</label>
                <input type="date" onChange={this.handleChange} 
                    name="dob" /><br/><br/>
            

                <label>Password:</label>
                <input type="password" onChange={this.handleChange} 
                    name="password" noValidate/>
                { errors.password.length > 0 && 
                <span className='error'>{errors.password}</span>}<br/><br/>
             

                <label>Confirm Password:</label>
                <input type="password" onChange={this.handleChange} 
                    name="cpassword" /><br/><br/>
             

                <label>Upload File:</label>
                <input type="file" onChange={this.handleChange} 
                    name="file" /><br/><br/>
            

                <button >Register</button>

                 {this.state.errorcount !== null ? <p>Form is {formvalid ? 'valid ' : 'invalid '}</p> : 'Form not submitted'}
            </form>
            </div>
        );
    }
}

export default Register;




