import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

class User extends Component {

    deleteUser =async () => {
        console.log(this.props.user._id)
     await axios.get(`http://localhost:4000/user/delete/${this.props.user._id}`)
            .then(console.log('deleted'))
            .catch(err=>console.log(err));
    }

    render() {
        return (
                <tr>
                    <td>{this.props.user.username}</td>
                    <td>{this.props.user.password}</td>
                    <td>
                        <Link to={"/edit/" + this.props.user._id}>
                        <button type="button" className="btn btn-outline-info">Edit</button>
                        </Link>
                    </td>
                    <td>
                        <button type="button" className="btn btn-outline-danger" onClick={this.deleteUser}>Delete</button>
                    </td>
                </tr>
        );
    }
}

export default User;