import React,{Component} from 'react';

class Register1 extends Component{

    constructor(props){
        super(props);
        this.state={
            firstname:'',
            lastname:'',
            username:'',
            email:'',
            dob:'',
            password:'',
            cpassword:'',
            file:'',
            errors:{ firstname:'',email:'',username:'',dob:'',password:'',cpassword:'',file:''},
            valids:{ firstname:false,email:false,username:false,dob:false,password:false,cpassword:false,file:false },
            formvalid:false,
        };
    }

    handleChange=(e)=>{
        const { name , value} = e.target;

        // image preload
        var file = this.refs.file.files[0];
        var reader = new FileReader();
        var url = reader.readAsDataURL(file);
      
         reader.onloadend = function (e) {
            this.setState({
                file: reader.result
            })
          }.bind(this);

        this.setState({[name]: value}, ()=>{ this.validate(name,value)});
    }
    validate(name,value){
        let fielderror = this.state.errors;
        let validate = this.state.valids;
         switch (name) {
            case 'firstname':
              validate.firstname = value.length > 5;
              fielderror.firstname = validate.firstname ? '':'Mininum length is 5';
              break;
            case 'username':
              validate.username = value.length > 5 && value.length < 10;
              fielderror.username = validate.username ? '':'Legth between 5 to 10';
              break;
            case 'password':
              validate.password = value.length > 8;
              fielderror.password = validate.password ? '':'Minimum length is 8';
              break;
            case 'cpassword':
              validate.cpassword = (value === this.state.password);
              fielderror.cpassword = validate.cpassword ? '':'Password and Confirm Password must be same';
              break;
            case 'email':
              validate.email = value.match(/\S+@\S+\.\S+/);
              fielderror.email = validate.email ? '': 'Email is not valid';
              break;
            
            default:
              break;
          }
          this.setState({errors :fielderror,
                         valids:validate  },this.validationForm )
    }

    validationForm()
    {
        let values = this.state.valids;
        this.setState({formvalid : values.firstname && values.username && values.email && values.password
                       && values.cpassword });
    }
    handleSubmit=(e)=>
    {
        e.preventDefault();
        console.log(this.state)
    }

    render(){
        return(
            <div><br/>
                <h4>Registration</h4><hr/>

            <form onSubmit={this.handleSubmit}>

                <div className="form-group">
                    <label>Firstname:</label>
                    <input type="text" className="form-control" onChange={this.handleChange}
                        value={this.state.firstname} placeholder="Firstname" name="firstname" />
                    <span>{this.state.errors.firstname}</span>
                </div>

                <div className="form-group">
                    <label>Lastname:</label>
                    <input type="text" onChange={this.handleChange} value={this.state.lastname}
                        name="lastname" className="form-control" placeholder="Lastname"/>
                    <span>{this.state.errors.lastname}</span>
                </div>

                <div className="form-group">
                <label>Username:</label>
                <input type="text" onChange={this.handleChange} value={this.state.username}
                    name="username" className="form-control" placeholder="Username"/>
                    <span>{this.state.errors.username}</span>
                </div>
   
                <div className="form-group">
                    <label>Email:</label>
                    <input type="text" onChange={this.handleChange} value={this.state.email}
                        name="email" className="form-control" placeholder="Email"/>
                    <span>{this.state.errors.email}</span>
                </div>
               
                <div className="form-group">
                    <label>Date of Birth:</label>
                    <input type="date" onChange={this.handleChange} value={this.state.dob}
                        name="dob" className="form-control" placeholder="Date Of Birth"/>
                    <span>{this.state.errors.dob}</span>
                </div>
            
                <div className="form-group">
                    <label>Password:</label>
                    <input type="password" onChange={this.handleChange} value={this.state.password}
                        name="password" className="form-control" placeholder="Password"/>
                    <span>{this.state.errors.password}</span>
                </div>
             
                <div className="form-group">
                    <label>Confirm Password:</label>
                    <input type="password" onChange={this.handleChange} value={this.state.cpassword}
                        name="cpassword" className="form-control" placeholder="Confirm Password"/>
                        <span>{this.state.errors.cpassword}</span>
                </div>
             
                <div className="form-group">
                    <label>Upload File:</label>
                    <input type="file" ref="file" onChange={this.handleChange}
                        name="file" className="form-control"  accept=".png, .jpg, .jpeg"/>
                    <span>{this.state.errors.file}</span>
                </div>

                <img width="100px" height="100px" src={this.state.file}/>

                <button disabled={!this.state.formvalid}>Register</button>

            </form>
            </div>
        );
    }
}

export default Register1;




