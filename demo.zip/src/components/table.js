
import React, { Component } from 'react';
import axios from 'axios';

const $ = require('jquery')
$.DataTable = require('datatables.net')

class Table extends Component {

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.data !== this.props.data) {
             var table = $(this.el).DataTable(
                {   
                    
                    data: this.props.data,
                    columns: [
                        { title: "username",data:"username" },
                        { title: "password",data:'password' },
                        { title: "Edit Record",defaultContent:`<button class="btn-view1">Edit</button>` },
                        { title: "Delete Record",defaultContent:`<button class="btn-view2">Delete</button>`},
                    ],                      
                }
            )
    
            table.on('click', '.btn-view1', function (e) {
                var id = table.rows($(this).closest("tr")).data()[0]._id;
                 window.location.href=("/edit/"+id)
             }); 

            table.on('click', '.btn-view2', function (e) {
            var id = table.rows($(this).closest("tr")).data()[0]._id;
                 axios.get(`http://localhost:4000/user/delete/${id}`)
                .then(console.log('delete'))
                .catch(err=>console.log(err));
            } );
         }   
    }

   
    render() {
        return (
            <div>
                <table className="display table table-striped" width="100%" ref={el => this.el = el}>
                </table>
            </div>
        );
    }
}

export default Table;

