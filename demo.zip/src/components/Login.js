import React from 'react';
import axios from 'axios';
import './login.css';

class Login extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            username: '',
            password: '',   
            submitted:false
        };
    }

    async setdata() {
        let data = this.state;
    //   await axios.post(`http://localhost:4000/user/add`,data)
    //         .then(res=>console.log(res.data));
        this.props.history.push('/');
    }

    handlechange = (event) => {
        const { name, value } = event.target;
        this.setState({ [name]: value });
    }

    validate()
    {
        const { username, password } = this.state;
        if (!(username && password)) {
            return
        }
        else if (password.length < 6) {
            return
        }
        else{
            this.setdata();
        }
    }

    handlesubmit = (event) => {
        event.preventDefault();
        this.setState({submitted:true});
        console.log(this.state)
        this.validate();
    }
    render() {
        var seterror = { color: 'red' }
        const { username, password, submitted } = this.state;
        return (
            <div>
                <br/>
                <h3>Login</h3><hr/>
                <form name="loginform" onSubmit={this.handlesubmit}>
                <div className="setform">
                    <div className="form-group">
                    <label>Username:</label>
                    <input type="text" className="form-control" value={this.state.username} onChange={this.handlechange} 
                        placeholder="Username" name="username"/>
                    <div style={seterror}>
                        {submitted && !username ? "Please enter Username" : null}
                    </div>
                    </div>

                     <div className="form-group">
                    <label>Password:</label>
                    <input type="password" className="form-control" value={this.state.password} onChange={this.handlechange} 
                        placeholder="password" name="password"/>
                    <div style={seterror}>
                        {submitted && !password ? "Please enter Password" : null}
                        {submitted && password && password.length < 6 ? ' Min length is 6' : null}
                    </div>
                    </div>

                    <button className="btn btn-primary">Login</button>
                </div>
                </form>
            </div>
        );
    }

}
export default Login;



