import React from 'react';
// import User from '../components/User'
import axios from 'axios';
import Table from '../components/table';

class Home extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            users: [],
            searchInput: "",
            filteredData: [],
        };
    }

    // handleChange = (event) => {
    //     this.setState({ searchInput: event.target.value }, () =>
    //         this.globalSearch()
    //     );
    // };

    // globalSearch = () => {
    //     const { searchInput, users } = this.state;
    //     const filteredData = users.filter(value => {
    //         return (
    //             value.username.toLowerCase().includes(searchInput.toLowerCase())
    //         );
    //     });
    //     this.setState({
    //         filteredData: filteredData
    //     });
    // };


    // get api
    async componentDidMount() {
        await axios.get(`http://localhost:4000/user`)
            .then(res => {
                if (res && res.data)
                    this.setState({ users: res.data })
            })
            .catch(err => console.log(err))
    }

    // displayUser() {
    //     if (this.state.searchInput == '') {
    //         return (this.state.users.map((user, index) =>
    //             <User key={index} user={user} />))
    //     }
    //     else {
    //         return (this.state.filteredData.map((user, index) =>
    //             <User key={index} user={user} />))
    //     }
    // }

    render() {
        return (
            <div>
                <hr />
                <Table data={this.state.users} />
                {/* <input
                    type="text"
                    name="searchInput"
                    value={this.state.searchInput || ""}
                    onChange={this.handleChange}
                    className="inputTag"
                    placeholder="Search"
                  />
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Username</th>
                            <th scope="col">Password</th>
                            <th scope="col">Edit</th>
                            <th scope="col">Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        { this.displayUser() }
                    </tbody>
                </table> */}
            </div>
        );
    }
}

export default Home;