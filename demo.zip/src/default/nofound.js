import React from 'react';

const nofound = ()=>(
    <h5>Page Not Found</h5>
);

export default nofound;
