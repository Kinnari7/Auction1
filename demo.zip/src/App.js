import React, { Component } from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import Routing from './routing/router';


class App extends Component {
  render() {
    return (   
        <Router>
         <Routing/>
        </Router>
    );
  }
}

export default App;
  
