import React, { Component } from 'react';
import { connect } from 'react-redux';

class EditPost extends Component{

    handleEdit=(e)=>{
        e.preventDefault();
        const newTitle = this.getTitle.value;
        const newMsg = this.getMessage.value;
        const data={
            newTitle,
            newMsg
        }

        // action
        this.props.dispatch({
            type:'UPDATE',
            id:this.props.post.id,
            data:data
        });
    }

    render(){
        return(
            <div className="post">
                <form className="form" onSubmit={this.handleEdit}>
                    <input type="text" ref={(input) => this.getTitle = input}
                     defaultValue={this.props.post.title} placeholder="Enter Post Title" required/>
                     <br/><br/>

                    <textarea rows="5" ref={(input) => this.getMessage = input}
                     defaultValue={this.props.post.message} cols="28" placeholder="Enter Post"required/>
                     <br/><br/>

                    <button>Update</button>
                </form>
            </div>
        );
    }
}

export default connect()(EditPost);