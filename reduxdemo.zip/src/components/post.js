import React, {Component} from 'react'
import {connect} from 'react-redux'
import { withRouter } from "react-router"
import { editPost , deletePost} from '../actions/actionMethods';

class Post extends Component{

    // action
    editPost=()=>{
        this.props.dispatch({
            type:'EDIT_POST',
            id:this.props.post.id
        });
    }

    deletePost=()=>{
        this.props.dispatch({
            type:'DELETE_POST',
            id:this.props.post.id
        });
    }
    
    // componentDidMount()
    // {
    //     this.props.editPost(this.props.post.id);
    //     this.props.deletePost(this.props.post.id);
    // }
    // editPost = ()=>{
    //     this.props.editPost(this.props.post.id);
    //     this.props.history.push('/editpost');
    // }
    // deletePost =()=>{
    //     this.props.deletePost(this.props.post.id);
    // }

    render(){
        return(
            <div className="post">
                <h2 className="post_title">{this.props.post.title}</h2>
                <p className="post_message">{this.props.post.message}</p>
                <button className="edit" onClick={this.editPost}>Edit</button>
                <button className="delete" onClick={this.deletePost}>Delete</button>
            </div>
        );
    }
}   

export default connect()(Post)

// const mapDispatchToProps = dispatch =>({
//         editPost:id=> dispatch(editPost(id)),
//         deletePost:data=>dispatch(deletePost(data))
// })
// export default withRouter(connect(null,mapDispatchToProps)(Post))