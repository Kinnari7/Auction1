import React,{Component} from 'react';

class Home extends Component{
    render(){
        return(
            <div>
                <h5>Home Page</h5>
            </div>
        );
    }
}

export default Home;