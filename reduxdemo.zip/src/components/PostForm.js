import React,{Component} from 'react';
import { connect } from 'react-redux';
import {addPost} from '../actions/actionMethods';

class PostForm extends Component{

    handleSubmit=(e)=>{
        e.preventDefault();
        const title = this.getTitle.value;
        const message = this.getMessage.value;
        const data={
            id:new Date(),
            title,
            message,
            editing:false
        }

        // action
        this.props.addPost(data)

        this.getTitle.value='';
        this.getMessage.value='';
        this.props.history.push('/post');
    }

    render(){
        return(
            <div className="post-container">
                <h1 className="post_heading">Create Post</h1>
                <form className="form" onSubmit={this.handleSubmit}>
                
                <input type="text" placeholder="Enter Post Title" required
                ref={(input)=>this.getTitle = input}/><br/><br/>

                <textarea rows="5" cols="28" placeholder="Enter Post" required
                ref={(input)=>this.getMessage = input}/><br/><br/>

                <button>Post</button>
                </form>
            </div>
        );
    }
}
const mapDispatchToProps = dispatch => {
    return {
        addPost: data => dispatch(addPost(data))
    }
}
export default connect(null, mapDispatchToProps)(PostForm);