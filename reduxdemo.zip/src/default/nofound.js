import React , {Component} from 'react';

class Nofound extends Component{

    render(){
        return(
            <div>
                <h5>Page Not Found</h5>
            </div>
        );
    }
}

export default Nofound;