import React from 'react';
import { Route, Link,Switch } from 'react-router-dom';
import Home from '../components/home';
import PostForm from '../components/PostForm';
import AllPost from '../components/AllPost';
import nofound from '../default/nofound';
import EditPost from '../components/EditPost';

class Routing extends React.Component{
    render(){
        return(
            <div>
                <ul>
                    <li><Link to="/">Home</Link></li>
                    <li><Link to="/postform">Add Post</Link></li>
                    <li><Link to="/post">PostList</Link></li>
                </ul> 
            <Switch>
                <Route exact path="/" component={Home} />
                <Route path="/postform" component={PostForm} />
                <Route path="/post" component={AllPost} />
                <Route path="/editpost" component={EditPost}/>
                <Route component={nofound}/>
            </Switch>
        </div>   
        );
    }
};

export default Routing;