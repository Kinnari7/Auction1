import * as type from '../actions/actionType';

export const addPost = (data) => {
    return { type: type.ADD_POST, data: data }
}

// export const editPost=(data)=>{
//     return { type:type.EDIT_POST,data:data}
// }

// export const deletePost=(data)=>{
//     return { type:type.DELETE_POST,data:data}
// }