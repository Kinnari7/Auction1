const jwt = require("jsonwebtoken");
const config = require("./config");

exports.checkToken = function (req, res, next) {
    let token = req.headers["x-access-token"] || req.headers["authorization"];
    if (token && token.startsWith("Bearer ")) {
        //remove bearer
        token = token.slice(7, token.length);
    }

    if (token) {
        jwt.verify(token, config.secret, function (err, decoded) {
            if (err) {
                return res.status(400).json({ msg: "Token is not valid" });
            }
            else {
                if (token === config.currentToken) {
                    req.decoded = decoded;
                    next();
                }
                else {
                    return res.status(400).json({ msg: "Old token detected. Invalid login" });
                }

            }
        })

    }
    else {
        return res.status(400).json({ msg: "Authorization token not supplied" });
    }
};