module.exports={
    secret:"thisisasecretSTRING!@*&^@&",
    currentToken:""
};