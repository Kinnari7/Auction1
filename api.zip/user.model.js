const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let User = new Schema({
    firstname: {
      type: String,
      require:true
    },
    lastname: {
      type: String
    },
    username:{
      type: String,
      required:true
    },
    email:{
      type: String,
      required:true
    },
    password:{
      type: String,
      required:true
    },
    cpassword:{
      type:String,
      required:true
    },
    dob:{
      type : Date,
      required:true
    },
    file:{
      type:String,
      required:true
    }
  },{
      collection: 'user'
  });
  
  module.exports = mongoose.model('user', User);