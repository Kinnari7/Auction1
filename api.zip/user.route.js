const express = require('express');
const UserRoute = express.Router();
const authenticate = require("./authenticate");
const config = require("./config");
let User = require('./user.model');

const multer = require("multer");
const storage = multer.diskStorage({
    destination:'./public/uploads',
    filename:function(req,file,cb){
      cb(null,"image-"+Date.now()+ path.extname(file.originalname));
    }
});
const upload = multer({
  storage:storage,
  limits:{ fileSize:5000},
}).single("myImage");


// add user
UserRoute.route('/add').post(function (req, res) {
  let user = new User(req.body);
  user.save()
    .then(user => {
      res.status(200).json({ 'user': 'Registered successfully' });
    })
    .catch(err => {
      res.status(400).send("unable to save to database");
    });
});

//login
UserRoute.route("/login").post(function (req, res) {
  const { username, password } = req.body;
  User.findOne({ username: username, password: password })
    .then(function onSuccess(result) {
      if (result != null && result != undefined) {
        let token = jwt.sign({ username: username }, config.secret, { expiresIn: "5h" });
        config.currentToken = token;
        res.status(200).json({ msg: "Login successful!", user: result, token: token });
      }
    })
    .catch(function onReject(err) {
      res.status(400).json({ msg: "Error Occurred", err: err });
    });
})

//UserRoute.use("/",authenticate.checkToken);

//   get all users
UserRoute.route('/').get(function (req, res) {
  User.find(function (err, user) {
    if (err) {
      console.log(err);
    }
    else {
      res.json(user);
    }
  });
});

//   edit user
UserRoute.route('/edit/:id').get(function (req, res) {
  let id = req.params.id;
  User.findById(id, function (err, user) {
    res.json(user);
  });
});


// update user
UserRoute.route('/update/:id').post(function (req, res) {
  User.findById(req.params.id, function (err, user) {
    if (!user)
      res.status(404).send("data is not found");
    else {
      user.username = req.body.username;
      user.password = req.body.password;

      user.save().then(user => {
        res.json('Update complete');
      })
        .catch(err => {
          res.status(400).send("unable to update the database");
        });
    }
  });
});


// delete user
UserRoute.route('/delete/:id').get(function (req, res) {
  User.findByIdAndRemove({ _id: req.params.id }, function (err, user) {
    if (err => console.log(err));
    else res.json('Successfully removed');
  });
});

module.exports = UserRoute;
