<!-- exports this varibale -->

export DB_PASSWORD="admin123"
export DB_HOST="localhost"
export DB_DATABASE="mysql"
export DB_USERNAME="root"
export DB_DATABASE_NAME="nodedemo"
export DB_PORT="3306"


<!-- get: function() {
          return moment.utc(this.getDataValue("dob")).format("YYYY-MM-DD");
        } -->