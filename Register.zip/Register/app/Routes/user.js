var express = require("express");
var router = express.Router();
const UserController = require("../Controllers/userController");
const checkAuthorization = require("../Config/auth.config").verifyToken;

const userController = new UserController();

router.get("/list", userController.list);

router.post("/login", userController.signIn);

router.post("/register", userController.signUp);

router.post("/add_user", checkAuthorization, userController.signUp);

router.put("/edit", checkAuthorization, userController.edit);

router.put(
  "/remove/address/:id",
  checkAuthorization,
  userController.removeAddress
);

router.delete("/delete/:id", checkAuthorization, userController.delete);

router.get("/data", checkAuthorization, userController.showUserData);

router.post("/profile/upload", checkAuthorization, userController.uploadImage);

router.get("/logout", checkAuthorization, userController.logOut);

router.put(
  "/change_password",
  checkAuthorization,
  userController.changePassword
);

router.put("/reset_password", userController.resetPassword);

router.post("/forgot_password", userController.forgotPassword);

router.get("/email_verify", userController.emailVerify);

module.exports = router;
