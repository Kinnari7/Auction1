var express = require("express");
const user = require("../Routes/user");
var router = express.Router();

router.use("/user", user);

module.exports = router;
