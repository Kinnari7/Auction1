const UserModel = require("../Models/index").userModel;
const Op = require("sequelize").Op;
const encryptPassword = require("../Config/auth.config").encryptPassword;
const comparePasswordHash = require("../Config/auth.config")
  .comparePasswordHash;
const generateToken = require("../Config/auth.config").generateToken;
const UserSession = require("../Models/index").userSession;
var multer = require("multer");
const successObj = require("../Utilities/responses").successObj;
const errorObj = require("../Utilities/responses").errorObj;
const addressDetails = require("../Models/index").addressDetails;
const UserAddress = require("../Models/index").userAddress;
var nodemailer = require("nodemailer");

var smtpConfig = {
  host: "smtp.gmail.com",
  port: 465,
  secure: true,
  auth: {
    user: "arpit.vyas@openxcellinc.com",
    pass: "123456!@#"
  }
};
var transporter = nodemailer.createTransport(smtpConfig);

class UserController {
  /* user sign up */

  async signUp(req, res) {
    const {
      first_name,
      last_name,
      password,
      email,
      dob,
      phone_number,
      address
    } = req.body;
    let encryptedPwd = await encryptPassword(password);
    UserModel.findOne({
      where: {
        [Op.or]: [{ email }]
      }
    })
      .then(sucObj => {
        if (sucObj) {
          errorObj(res, RESPONSE.USER_ALREADY_EXITS, sucObj);
        } else {
          UserModel.create({
            first_name,
            last_name,
            email,
            password: encryptedPwd,
            dob,
            phone_number
          })
            .then(async user => {
              const addressArray = [];
              address.map(item => {
                addressArray.push({
                  userId: user.id,
                  address: item.address,
                  city: item.city,
                  state: item.state,
                  pin_code: item.pin_code
                });
              });
              const users_address = await UserAddress.bulkCreate(addressArray);
              if (users_address) {
                successObj(res, RESPONSE.USER_CREATED, user);
              }
            })
            .catch(errObj => {
              errorObj(res, RESPONSE.FAILED, errObj);
            });
        }
      })
      .catch(errObj => {
        errorObj(res, RESPONSE.FAILED, errObj);
      });
  }

  /* user login */

  async signIn(req, res) {
    const { email, password } = req.body;
    UserModel.findOne({
      where: {
        email
      }
    })
      .then(async sucObj => {
        let result = await comparePasswordHash(password, sucObj.password);
        if (result) {
          let token = await generateToken(email);
          UserSession.create({ token, userId: sucObj.id })
            .then(sucObj => {
              successObj(res, RESPONSE.SUCCESS, { sucObj });
            })
            .catch(errObj => {
              errorObj(res, RESPONSE.FAILED, errObj);
            });
        } else {
          successObj(res, RESPONSE.INCORRECT_PASSWORD);
        }
      })
      .catch(err => {
        successObj(res, RESPONSE.DATA_NOT_FOUND);
      });
  }

  /* list of users */

  async list(req, res) {
    let associatedRes = await UserModel.findAll({
      attributes: [
        "first_name",
        "last_name",
        "phone_number",
        "dob",
        "email",
        "id"
      ],
      include: addressDetails
    });
    successObj(res, RESPONSE.SUCCESS, associatedRes);
  }

  /* remove address from User Address modal */

  removeAddress(req, res) {
    const id = req.sucObj.userId;
    UserAddress.findOne({
      where: {
        id: req.params.id
      }
    })
      .then(async sucObj => {
        if (sucObj) {
          await sucObj
            .destroy()
            .then(success => {
              successObj(res, RESPONSE.SUCCESS, success);
            })
            .catch(() => errorObj(res, RESPONSE.INTERNAL_SERVER_ERROR));
        }
      })
      .catch(errObj => {
        errorObj(res, RESPONSE.DATA_NOT_FOUND, errObj);
      });
  }

  /* edit user details */

  edit(req, res) {
    const id = req.sucObj.userId;
    const addressArray = [];
    UserModel.findOne({
      where: {
        id: id
      }
    })
      .then(sucObj => {
        if (sucObj) {
          const {
            first_name,
            last_name,
            dob,
            phone_number,
            address
          } = req.body;
          sucObj
            .update({
              first_name,
              last_name,
              dob,
              phone_number
            })
            .then(user => {
              address.map(item => {
                UserAddress.findOne({
                  where: {
                    id: item.id
                  }
                })
                  .then(sucObj => {
                    sucObj
                      .update({
                        address: item.address,
                        city: item.city,
                        pin_code: item.pin_code,
                        state: item.state
                      })
                      .then(sucObj => {
                        successObj(res, RESPONSE.DATA_UPDATED, sucObj);
                      });
                  })
                  .catch(async errObj => {
                    addressArray.push({
                      userId: user.id,
                      address: item.address,
                      city: item.city,
                      state: item.state,
                      pin_code: item.pin_code
                    });
                    const users_address = await UserAddress.bulkCreate(
                      addressArray
                    );
                    if (users_address) {
                      successObj(res, RESPONSE.DATA_UPDATED, user);
                    } else {
                      errorObj(res, RESPONSE.FAILED, errObj);
                    }
                  });
              });
            })
            .catch(errObj => {
              errorObj(res, RESPONSE.FAILED, errObj);
            });
        }
      })
      .catch(err => {
        res.send(err);
      });
  }

  /* upload image */

  uploadImage(req, res) {
    var storage = multer.diskStorage({
      destination: function(req, file, cb) {
        cb(null, "Uploads/");
      },
      filename: function(req, file, cb) {
        cb(null, file.fieldname + "-" + Date.now());
      }
    });
    var upload = multer({ storage: storage }).single("profileImage");
    upload(req, res, function(err) {
      if (err instanceof multer.MulterError) {
      }
      successObj(res, RESPONSE.SUCCESS);
    });
  }

  /* User Addresses */

  showUserData(req, res) {
    const id = req.sucObj.userId;
    UserModel.findOne({
      attributes: ["first_name", "last_name", "phone_number", "dob"],
      where: {
        id: id
      },
      include: addressDetails
    })
      .then(user => {
        successObj(res, RESPONSE.SUCCESS, user);
      })
      .catch(err => {
        errorObj(res, RESPONSE.FAILED, err);
      });
  }

  /* Delete User Data */

  async delete(req, res) {
    UserModel.findOne({
      where: {
        id: req.params.id
      }
    })
      .then(async sucObj => {
        await sucObj.destroy().then(sucObj => {
          successObj(res, RESPONSE.DELETED);
        });
      })
      .catch(errObj => {
        errorObj(res, RESPONSE.FAILED, errObj);
      });
  }

  /* user logout */

  async logOut(req, res) {
    UserSession.findOne({
      where: {
        token: req.headers["user_token"]
      }
    })
      .then(async sucObj => {
        if (sucObj) {
          await sucObj
            .destroy()
            .then(success => {
              successObj(res, RESPONSE.LOGOUT);
            })
            .catch(() => errorObj(res, RESPONSE.INTERNAL_SERVER_ERROR));
        }
      })
      .catch(() => successObj(res, RESPONSE.DATA_NOT_FOUND));
  }

  /* change password */

  changePassword(req, res) {
    const id = req.sucObj.userId;
    UserModel.findOne({
      where: {
        id: id
      }
    })
      .then(async sucObj => {
        if (sucObj) {
          const { old_password, new_password } = req.body;
          let result = await comparePasswordHash(old_password, sucObj.password);
          if (result) {
            let password = await encryptPassword(new_password);
            sucObj
              .update({
                password: password
              })
              .then(sucObj => {
                successObj(res, RESPONSE.PASSWORD_CHANGED, sucObj);
              })
              .catch(errObj => {
                errorObj(res, RESPONSE.FAILED, errObj);
              });
          } else {
            errorObj(res, RESPONSE.INCORRECT_PASSWORD);
          }
        }
      })
      .catch(err => {
        errorObj(res, RESPONSE.FAILED, err);
      });
  }

  /* forgot password */

  async forgotPassword(req, res) {
    const { email } = req.body;
    UserModel.findOne({
      where: {
        email
      }
    })
      .then(async success => {
        if (success) {
          let generatedToken = await generateToken(email);
          let token = generatedToken;
          success
            .update({
              reset_pass_token: token
            })
            .then(sucObj => {
              let link =
                "http://localhost:3000" +
                "/user/reset-password/?token=" +
                token;
              var mailOptions = {
                from: "arpit.vyas@openxcellinc.com",
                to: req.body.email,
                subject: "Email verification",
                html:
                  "<b>Please hit below link to Reset Password</b><br/>" + link
              };
              transporter.sendMail(mailOptions, function(error, info) {
                if (error) {
                  errorObj(res, RESPONSE.FAILED, error);
                } else {
                  successObj(res, RESPONSE.EMAIL_SENT, mailOptions);
                }
                transporter.close();
              });
            })
            .catch(errObj => {
              errorObj(res, RESPONSE.FAILED, errObj);
            });
        } else {
          errorObj(res, RESPONSE.DATA_NOT_FOUND);
        }
      })
      .catch(error => {});
  }

  /* email verification for forgot password */

  emailVerify(req, res) {
    const { token } = req.body;
    UserModel.findOne({
      where: {
        reset_pass_token: token
      }
    })
      .then(sucObj => {
        console.log("TCL: UserController -> emailVerify -> sucObj", sucObj);
        if (sucObj) {
          successObj(res, RESPONSE.EMAIL_VERIFIED);
          setTimeout(function() {
            console.log("this will execute");
            sucObj.update({
              reset_pass_token: ""
            });
          }, 100000);
        } else {
          errorObj(res, RESPONSE.TOKEN_EXPIRE);
        }
      })
      .catch(errObj => {
        errorObj(res, RESPONSE.FAILED, errObj);
      });
  }

  /* reset password */

  async resetPassword(req, res) {
    const { password, token } = req.body;
    let encryptedPwd = await encryptPassword(password);
    UserModel.findOne({
      where: {
        reset_pass_token: token
      }
    })
      .then(sucObj => {
        sucObj
          .update({
            password: encryptedPwd
          })
          .then(sucObj => {
            successObj(res, RESPONSE.PASSWORD_CHANGED);
          })
          .catch(errObj => {
            errorObj(res, RESPONSE.FAILED);
          });
      })
      .catch(errObj => {
        errorObj(res, RESPONSE.TOKEN_EXPIRE);
      });
  }
}

module.exports = UserController;
