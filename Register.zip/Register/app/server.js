var express = require("express");
var app = express();
var cors = require("cors");
var routes = require("../app/Routes");
require("./Utilities/status");
require("dotenv").config({ path: "../.env" });
const bodyParser = require("body-parser");

/* for default path */

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors(),function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "http://localhost:3000"); // update to match the domain you will make the request from
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
  });
app.use("/", routes);

app.use(function(req, res, next) {
  res.send("requested page not found!");
});

var server = app.listen(8085, function() {});
