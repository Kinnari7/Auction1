const Bcryptjs = require("bcryptjs");
const generatedSalt = Bcryptjs.genSaltSync(10);
const JwtToken = require("jsonwebtoken");
const jwtObject = require("../Utilities/constants").jwtObject;
const cipherObject = require("../Utilities/constants").cipherObject;
const UserSession = require("../Models/index").userSession;
const successObj = require("../Utilities/responses").successObj;
const errorObj = require("../Utilities/responses").errorObj;
var crypto = require("crypto");

/* encrypt password */

async function encryptPassword(password) {
  let hashed = await Bcryptjs.hash(password, generatedSalt).then(hash => {
    return hash;
  });
  return hashed;
}

/* compare entered password with decrypted password */

async function comparePasswordHash(enteredPassword, hashedPassword) {
  let result = await Bcryptjs.compare(enteredPassword, hashedPassword)
    .then(sucObj => {
      return sucObj;
    })
    .catch(errObj => {
      return errObj;
    });
  return result;
}

/* token generate */

async function generateToken(email) {
  var date = new Date();
  var text = email + date.getTime();

  var cipher = crypto.createCipher(cipherObject.algo, cipherObject.secret);
  var encrypted = cipher.update(text, "utf8", "hex") + cipher.final("hex");

  return encrypted;
  // var decipher = crypto.createDecipher(cipherObject.algo, cipherObject.secret);
  // var decrypted = decipher.update(encrypted, 'hex', 'utf8') + decipher.final('utf8');
  // console.log('decrypted', decrypted);

  /* Generate JWT Token
    
    console.log(encryptPassword(userObj.email))
    let token = await JwtToken.sign(userObj, jwtObject.secret, {
        algorithm: jwtObject.algo
    });
    return token; */
}

/* Verify token with JWT */

async function verifyJWTToken(req, res, next) {
  let token = req.headers["user_token"];
  if (token) {
    JwtToken.verify(
      token,
      jwtObject.secret,
      {
        algorithms: [jwtObject.algo]
      },
      function(err, result) {
        err
          ? errorObj(res, RESPONSE.UNAUTHORIZED_USER)
          : UserSession.findOne({
              where: {
                token: token,
                userId: result.userId
              }
            })
              .then(sucObj => {
                if (sucObj) {
                  console.log("verfiy token", sucObj);
                  next();
                } else {
                  errorObj(res, RESPONSE.DATA_NOT_FOUND);
                }
              })
              .catch(errObj => {
                errorObj(res, RESPONSE.UNAUTHORIZED_USER);
              });
      }
    );
  } else {
    errorObj(res, RESPONSE.INVALID_HEADERS);
  }
}

/* verify token  */

async function verifyToken(req, res, next) {
  let token = req.headers["user_token"];
  if (token) {
    UserSession.findOne({
      where: {
        token: token
      }
    })
      .then(sucObj => {
        if (sucObj) {
          req.sucObj = sucObj;
          next();
        } else {
          errorObj(res, RESPONSE.DATA_NOT_FOUND);
        }
      })
      .catch(errObj => {
        errorObj(res, RESPONSE.UNAUTHORIZED_USER);
      });
  } else {
    errorObj(res, RESPONSE.INVALID_HEADERS);
  }
}

module.exports = {
  encryptPassword,
  comparePasswordHash,
  generateToken,
  verifyJWTToken,
  verifyToken
};
