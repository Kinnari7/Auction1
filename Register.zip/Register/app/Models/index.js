const seqObj = require("../Config/db.config");
const Sequalize = require("sequelize");
const user_model = require("./user");
const user_session = require("./session");
const user_address = require("./user_address");

const userModel = user_model(seqObj, Sequalize);
module.exports["userModel"] = userModel;

const userSession = user_session(seqObj, Sequalize);
module.exports["userSession"] = userSession;

const userAddress = user_address(seqObj, Sequalize);
module.exports["userAddress"] = userAddress;

// Association

userAddress.belongsTo(userModel);

userModel.hasMany(userSession, {
  as: "ongoingSession",
  foreignKey: "userId"
});

const addressDetails = userModel.hasMany(userAddress, {
  as: "userAddress",
  foreignKey: "userId",
  onDelete: "cascade",
  hooks: true
});
module.exports["addressDetails"] = addressDetails;
