/* jshint indent: 2 */
var moment = require("moment");
module.exports = function(sequelize, DataTypes) {
  return sequelize.define(
    "user",
    {
      first_name: {
        type: DataTypes.STRING(11),
        allowNull: false
      },
      last_name: {
        type: DataTypes.STRING(11),
        allowNull: false
      },
      email: {
        type: DataTypes.STRING(255),
        allowNull: false
      },
      password: {
        type: DataTypes.STRING(255),
        allowNull: false
      },
      id: {
        type: DataTypes.INTEGER(8),
        allowNull: false,
        primaryKey: true,
        autoIncrement: true
      },
      dob: {
        type: DataTypes.DATEONLY,
        allowNull: true,
        get: function() {
          return moment.utc(this.getDataValue("dob")).format("YYYY-MM-DD");
        }
      },
      phone_number: {
        type: DataTypes.INTEGER(20),
        allowNull: false
      },
      reset_pass_token: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: sequelize.literal("CURRENT_TIMESTAMP")
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: sequelize.literal("CURRENT_TIMESTAMP")
      }
    },
    {
      tableName: "user"
    }
  );
};
