const RESPONSE = {
  SUCCESS: {
    MESSAGE: "Success",
    CODE: 200
  },
  USER_CREATED: {
    MESSAGE: "User Created",
    CODE: 201
  },
  LOGOUT: {
    MESSAGE: "Log Out Sucessfully",
    CODE: 204
  },
  DATA_NOT_FOUND: {
    MESSAGE: "User not found",
    CODE: 404
  },
  USER_ALREADY_EXITS: {
    MESSAGE: " User already Exist",
    CODE: 403
  },
  INCORRECT_PASSWORD: {
    MESSAGE: "Incorrect password",
    CODE: 401
  },
  FAILED: {
    MESSAGE: "Failed!",
    CODE: 400
  },
  UNAUTHORIZED_USER: {
    MESSAGE: "Unauthorized User",
    CODE: 401
  },
  INVALID_HEADERS: {
    MESSAGE: "Invalid Headers",
    code: 400
  },
  INTERNAL_SERVER_ERROR: {
    MESSAGE: "Internel server error",
    CODE: 500
  },
  EMAIL_SENT: {
    MESSAGE: "Email Sent Successfully!",
    CODE: 200
  },
  PASSWORD_CHANGED: {
    MESSAGE: "Your Password Changed Successfully!",
    CODE: 200
  },
  TOKEN_EXPIRE: {
    MESSAGE: "Your Token has been Expired!",
    CODE: 404
  },
  EMAIL_VERIFIED: {
    MESSAGE: "Your Email Has been Verified Successfully!",
    CODE: 200
  },
  DATA_UPDATED: {
    MESSAGE: "Your Data Has been Successfully Upadted!",
    CODE: 200
  },
  DELETED: {
    MESSAGE: "User Deleted Successfully!",
    CODE: 200
  }
};

global.RESPONSE = RESPONSE;
