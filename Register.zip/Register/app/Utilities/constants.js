const jwtObject = {
    algo: "HS512",
    secret: "thatssecret"
}

const cipherObject = {
    algo: "aes256",
    secret:"token"
}

module.exports = {
    jwtObject, cipherObject
}