
//send response

function successObj(res, status, data) {
    res.send({
        status, data
    })
}
function errorObj(res, status, data) {
    res.send({
        status,
        data
    })
}

module.exports = { successObj, errorObj }