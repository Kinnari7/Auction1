const HOST = "http://localhost:8085/user";

export { HOST };
