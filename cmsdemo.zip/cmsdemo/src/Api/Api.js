import axios from "axios";
import React from "react";
import { HOST } from "./Constant";

const HEADERS = {
  "content-type": "application/json"
};
export default class Api extends React.Component {
  constructor() {
    super();
    if (localStorage.getItem("token") && localStorage.getItem("token")) {
      HEADERS["user_token"] = localStorage.getItem("token");
    }
  }
  async put(url, payload) {
    return await axios(`${HOST}/${url}`, {
      method: "put",
      headers: HEADERS,
      data: payload
    })
      .then(response => {
        return response.data;
      })
      .catch(error => {
        throw error;
      });
  }

  async post(url, payload) {
    return await axios(`${HOST}/${url}`, {
      method: "post",
      headers: HEADERS,
      data: payload
    })
      .then(response => {
        return response.data;
      })
      .catch(error => {
        throw error;
      });
  }

  async get(url, payload) {
    return await axios(`${HOST}/${url}`, {
      method: "get",
      headers: HEADERS,
      data: payload
    })
      .then(response => {
        return response.data;
      })
      .catch(error => {
        throw error;
      });
  }

  async delete(url, payload) {
    return await axios(`${HOST}/${url}`, {
      method: "delete",
      headers: HEADERS,
      data: payload
    })
      .then(response => {
        return response.data;
      })
      .catch(error => {
        throw error;
      });
  }
}
