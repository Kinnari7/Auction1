import React from "react";
import { Switch, Route, Redirect } from "react-router-dom";
import LogIn from "../Components/LogIn/LogIn";
import Register from "../Components/Register/Register";
import UsersInfo from "../Components/UserInfo/UserInfo";
import Default from "../Components/Default/Default";
import ChangePassword from "../Components/Settings/ChangePassword";
import Sidebar from "../Components/Sidebar/Sidebar";
import Header from "../Components/Header/Header";
import Profile from "../Components/Profile/Profile";
import DashBoard from "../Components/DashBoard/DashBoard";
import ResetPassword from "../Components/LogIn/ResetPassword";
import { PrivateRoute } from "./Authentication";
export default class Routes extends React.Component {
  render() {
    return (
      <Switch>
        <Route exact path="/" render={() => <Redirect to="/login" />} />
        <Route path="/login" component={LogIn} />
        <Route path="/register" component={Register} />
        <Route path="/user/reset-password" component={ResetPassword} />
        <Route component={defaultContainer} />
      </Switch>
    );
  }
}

const defaultContainer = () => {
  return (
    <div>
      <Header />
      <Sidebar />
      <Switch>
        <PrivateRoute path="/users-info" component={UsersInfo} />
        <PrivateRoute path="/change-password" component={ChangePassword} />
        <PrivateRoute path="/dashboard" component={DashBoard} />
        <PrivateRoute path="/profile" component={Profile} />
        <PrivateRoute component={Default} />
      </Switch>
    </div>
  );
};
