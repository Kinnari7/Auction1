import React from "react";
import { Route, Redirect } from "react-router-dom";

export function PrivateRoute({ component: Component, authed, ...rest }) {
  const id = localStorage.getItem("id") ? localStorage.getItem("id") : "";
  return (
    <Route
      {...rest}
      render={props =>
        id ? (
          <Component {...props} />
        ) : (
          <Redirect
            to={{ pathname: "/login", error:'Your Session is Expired!' }}
          />
        )
      }
    />
  );
}
