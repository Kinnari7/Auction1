import React from "react";
import Form from "../Common/form.style";
import Global from "../Common/global.style";
import Modal from "../Common/Modal";
import Api from "../../Api/Api";

export default class Profile extends React.Component {
  state = { data: undefined };

  async componentDidMount() {
    const response = await new Api().get(`/data`);
    this.setState({
      data: response.data
    });
  }

  render() {
    const { data } = this.state;
    return (
      <Global>
        <Form
          height="auto"
          width="40%"
          inputMargin="3px 0"
          inputPadding="9px 20px"
          shadow="0 6px 6px -3px rgba(0, 0, 0, 0.2), 0 10px 14px 1px rgba(0, 0, 0, 0.14), 0 4px 18px 3px rgba(0, 0, 0, 0.12) !important"
          margin="40px auto 2px"
        >
          {data && <Modal editUserData={data} profile="profile" />}
        </Form>
      </Global>
    );
  }
}
