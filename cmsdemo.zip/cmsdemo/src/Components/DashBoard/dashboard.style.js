import styled from "styled-components";

const DashBoardWrapper = styled.div`
.left {
  margin: 10px auto 0 100px;
  padding: 20px 0 20px 0;
  width: 30%;
  height: 100%;
  float:left;
}

.right{
  margin: 10px 100px 0;
  padding: 20px 0 20px 0
  width: 30%;
  float:right;
  height: auto;
  }

  
  @media screen and (max-width: 768px) {
    .left{
      margin:10px auto 0 auto;
      height:auto;
      width: 80%
      float:left
    }
    .right{
      margin:10px auto 0 auto;
      height:auto;
      float:left
      width: 80%
    }
`;

export default DashBoardWrapper;
