import React from "react";
import Highcharts from "highcharts";
import Global from "../Common/global.style";
import DashBoardWrapper from "./dashboard.style";

export default class DashBoard extends React.Component {
  state = {
    bar_chart: "",
    pie_chart: ""
  };

  barChart = {
    chart: {
      type: "bar"
    },
    title: {
      text: "Bar Chart"
    },
    series: [
      {
        data: [
          { name: "Chrome", y: 61.41, sliced: true },
          { name: "Internet Explorer", y: 11.84 },
          { name: "Firefox", y: 10.85 },
          { name: "Edge", y: 4.67 },
          { name: "Safari", y: 4.18 }
        ]
      }
    ]
  };

  pieChart = {
    chart: {
      type: "pie"
    },
    title: {
      text: "Pie Chart"
    },
    series: [
      {
        data: [
          { name: "Chrome", y: 61.41, sliced: true },
          { name: "Internet Explorer", y: 11.84 },
          { name: "Firefox", y: 10.85 },
          { name: "Edge", y: 4.67 },
          { name: "Safari", y: 4.18 }
        ]
      }
    ]
  };

  areaChart = {
    chart: {
      type: "area"
    },
    title: {
      text: "Area Chart"
    },
    series: [
      {
        data: [
          { name: "Chrome", y: 61.41, sliced: true },
          { name: "Internet Explorer", y: 11.84 },
          { name: "Firefox", y: 10.85 },
          { name: "Edge", y: 4.67 },
          { name: "Safari", y: 4.18 }
        ]
      }
    ]
  };

  donutChart = {
    chart: {
      type: "pie",
      options3d: {
        enabled: true,
        alpha: 45
      }
    },
    title: {
      text: "Donut Chart"
    },
    plotOptions: {
      pie: {
        innerSize: 100,
        depth: 45
      }
    },
    series: [
      {
        name: "Delivered amount",
        data: [
          ["Bananas", 8],
          ["Kiwi", 3],
          ["Mixed nuts", 1],
          ["Oranges", 6],
          ["Apples", 8],
          ["Pears", 4],
          ["Clementines", 4],
          ["Reddish (bag)", 1],
          ["Grapes (bunch)", 1]
        ]
      }
    ]
  };
  componentDidMount() {
    this.setState({
      bar_chart: Highcharts.chart("bar-id", this.barChart),
      pie_chart: Highcharts.chart("pie-id", this.pieChart),
      area_chart: Highcharts.chart("area-id", this.areaChart),
      donut_chart: Highcharts.chart("donut-id", this.donutChart)
    });
  }
  render() {
    return (
      <Global>
        <DashBoardWrapper>
          <div className="info">
            <div className="bg">
              <div className="left" id="bar-id" />
              <div id="pie-id" className="right" />
              <br />
              <div id="area-id" className="right" />
              <div id="donut-id" className="left" />
            </div>
          </div>
        </DashBoardWrapper>
      </Global>
    );
  }
}
