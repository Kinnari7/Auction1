import styled from "styled-components";

const SideWrapper = styled.div`
  .sidebar {
    height: 100%;
    width: 190px;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #241d3b;
    overflow-x: hidden;
    padding-top: 7px;
    font-family: 'Niramit', sans-serif;
    box-shadow: ${props =>
      props.shadow ||
      "0 6px 6px -3px rgba(0, 0, 0, 0.2), 0 10px 14px 1px rgba(0, 0, 0, 0.14), 0 4px 18px 3px rgba(0, 0, 0, 0.12) !important"};
  }

  .sidebar a {
    padding: 6px 8px 6px 16px;
    text-decoration: none;
    font-size: 24px;
    color: #818181;
    font-family: 'Niramit', sans-serif;
    display: block;
  }

  .sidebar .active {
    color: #f1f1f1;
  }

  .sidebar a:hover {
    color: #f1f1f1;
  }

  @media screen and (max-width: 511px) {
    .sidebar {
      padding-top: 15px;
      width: 0;
      left: 0;
    }
    .sidebar a {
      font-size: 18px;
    }
  }
`;

export default SideWrapper;
