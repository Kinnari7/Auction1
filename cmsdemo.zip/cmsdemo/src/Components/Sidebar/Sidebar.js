import React from "react";
import SideWrapper from "./sidebar.style";
import { Link } from "react-router-dom";

export default class Sidebar extends React.Component {
  render() {
    return (
      <SideWrapper>
        <div className="sidebar">
          <Link
            to="/dashboard"
            className={
              window.location.pathname === "/dashboard" ? "active" : ""
            }
          >
            <i className="fa fa-tachometer" aria-hidden="true">
              &nbsp; Dashboard
            </i>
          </Link>
          <Link
            to="/users-info"
            className={
              window.location.pathname === "/users-info" ? "active" : ""
            }
          >
            <i className="fa fa-users" aria-hidden="true">
              &nbsp; Users
            </i>
          </Link>
        </div>
      </SideWrapper>
    );
  }
}
