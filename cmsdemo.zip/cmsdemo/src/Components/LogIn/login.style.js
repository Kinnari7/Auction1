import styled from "styled-components";

const LogInWrapper = styled.div`
  overflow: hidden;
  span.psw {
    float: right;
    padding-top: 16px;
    color: red;
  }

  span.psw a {
    color: red;
  }

  span.register {
    text-align: center;
    padding-top: 16px;
  }

  @media screen and (max-width: 511px) {
    span.psw {
      display: block;
      float: none;
    }
  }
`;

export default LogInWrapper;
