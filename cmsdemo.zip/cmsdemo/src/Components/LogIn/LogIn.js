import React from "react";
import LogInWrapper from "../LogIn/login.style";
import { Redirect } from "react-router-dom";
import Form from "../Common/form.style";
import Input from "../Common/Validation";
import Api from "../../Api/Api";
import Notification from "../Common/Toast/Toast";

export default class LogIn extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      newUser: false,
      login: false,
      toast: undefined
    };
    this.onSubmit = this.onSubmit.bind(this);
  }

  componentDidMount() {
    console.log(this.props);
    if (this.props.location && this.props.location.error) {
      this.setState({
        toast: this.props.location.error
      });
    }
    localStorage.clear();
  }
  async onSubmit(payload) {
    const response = await new Api().post("login", payload);
    if (response && response.status.CODE === 200) {
      this.setState(
        {
          login: true
        },
        () => {
          localStorage.setItem("id", response.data.sucObj.userId);
          localStorage.setItem("token", response.data.sucObj.token);
        }
      );
    } else {
      this.setState({
        toast: response.status.MESSAGE
      });
    }
  }

  timeOut = () => {
    this.setState({
      toast: undefined
    });
  };

  /* Redirect to register */

  redirectToRegister = () => {
    this.setState({
      newUser: true
    });
  };

  render() {
    const { toast } = this.state;
    if (this.state.newUser) {
      return <Redirect to="/register" />;
    }
    if (this.state.login) {
      return <Redirect to="/dashboard" />;
    }
    return (
      <Form
        height="auto"
        margin="190px auto 120px"
        inputMargin="15px 0"
        inputPadding="10px 20px"
        btnFloat="left"
        bgColor="#241D3B"
        btnMargin="10px 0"
      >
        <LogInWrapper>
          <div className="form">
            <div className="container">
              <Input
                type="text"
                label="Email"
                placeholder="Enter Your Email"
                name="email"
                required={true}
                message="Please enter valid email"
              />
              <Input
                type="password"
                label="Password"
                placeholder="Enter Password"
                name="password"
                required={true}
              />
              <Input type="submit" name="LogIn" formSubmit={this.onSubmit} />
            </div>
            <div className="container">
              <button
                type="button"
                className="primaryBtn"
                onClick={() => this.redirectToRegister()}
              >
                Register
              </button>
              <span className="psw">
                Forgot <a href="#forgot_password">password?</a>
              </span>
              {toast && <Notification message={toast} timeOut={this.timeOut} />}
              <br />
              <br />
              <br />
              <br />
            </div>
          </div>
        </LogInWrapper>
      </Form>
    );
  }
}
