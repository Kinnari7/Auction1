import React from "react";
import Input from "../Common/Validation";
import Form from "../Common/form.style";

export default class ResetPassword extends React.Component {
  componentDidMount() {
    const params = new URLSearchParams(this.props.location.search);
    const token = params.get("token");
    console.log(token);
  }

  render() {
    return (
      <Form
        height="auto"
        width="350px"
        inputMargin="15px 0"
        inputPadding="12px 20px"
      >
        <div className="info">
          <div className="form">
            <div className="container">
              <Input
                type="password"
                label="New Password"
                placeholder="Enter New Password"
                name="new_password"
                required={true}
              />
              <Input
                type="password"
                label="Confirm Password"
                placeholder="Re-Enter Password"
                name="confirm_password"
                required={true}
              />
              <Input
                type="submit"
                className="primaryBtn"
                name="Change Password"
                formSubmit={this.onSubmit}
              />
              <br />
              <br />
              <br />
            </div>
          </div>
        </div>
      </Form>
    );
  }
}
