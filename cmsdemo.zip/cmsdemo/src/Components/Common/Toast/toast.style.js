import styled from "styled-components";

const Toast = styled.div`
  .show {
    min-width: 250px;
    margin-right: auto;
    background-color: #92929cd9;
    color: white;
    border-radius: 2px;
    padding: 16px;
    position: fixed;
    z-index: 1;
    right: 2%;
    top: 70px;
    font-family: "Niramit", sans-serif;
    font-size: 17px;
    visibility: visible;
    float: right;
    -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
    animation: fadein 0.5s, fadeout 0.5s 2.5s;
  }

  @-webkit-keyframes fadein {
    from {
      right: 0;
      opacity: 0;
    }
    to {
      right: 30px;
      opacity: 1;
    }
  }

  @keyframes fadein {
    from {
      right: 0;
      opacity: 0;
    }
    to {
      right: 30px;
      opacity: 1;
    }
  }
  @-webkit-keyframes fadeout {
    from {
      right: 0;
      opacity: 0;
    }
    to {
      right: 30px;
      opacity: 1;
    }
  }

  @keyframes fadeout {
    from {
      right: 0;
      opacity: 0;
    }
    to {
      right: 30px;
      opacity: 1;
    }
  }
`;

export default Toast;
