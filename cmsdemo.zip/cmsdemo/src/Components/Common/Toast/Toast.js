import React from "react";
import Toast from "./toast.style";
export default class Notification extends React.Component {
  state = {
    toast: false
  };
  componentDidMount() {
    setTimeout(() => {
      this.props.timeOut();
    }, 2000);
  }
  render() {
    const { message } = this.props;
    return (
      <div>
        <Toast>
          <div className="show">{message}</div>
        </Toast>
      </div>
    );
  }
}
