import React from "react";
import { validator, formData, password, addressArray } from "./Validator";
import { address } from "../UserInfo/users";
import Api from "../../Api/Api";

export default class Input extends React.Component {
  constructor() {
    super();
    this.state = {
      userInfo: {},
      error: "",
      submit: false,
      addresses: []
    };
    this.validator = validator;
    this.formData = formData;
    this.password = password;
    this.addressArray = addressArray;
  }

  componentWillUnmount() {
    Object.keys(this.validator).forEach(fieldName => {
      this.validator[fieldName].errors = [];
      this.validator[fieldName].state = "";
      this.validator[fieldName].valid = false;
    });
    this.addressArray.length = 0;
    this.password["confirm_password"] = "";
    for (var key in this.formData) {
      delete this.formData[key];
    }
  }

  componentDidMount() {
    const { type, name, required, defaultValue } = this.props;
    if (type !== "submit") {
      if (type === "add_address") {
        let defaultAddress = [];
        if (defaultValue) {
          defaultValue.forEach(item => {
            this.addressArray.push({
              id: item.id,
              address: item.address,
              city: item.city,
              pin_code: item.pin_code,
              state: item.state
            });
            defaultAddress.push({
              id: item.id,
              address: item.address,
              city: item.city,
              pin_code: item.pin_code,
              state: item.state
            });
          });
        } else {
          defaultAddress.push({
            address: undefined,
            pin_code: undefined,
            state: "Gujarat, India",
            city: undefined
          });
          this.addressArray.push({
            address: undefined,
            pin_code: undefined,
            state: "Gujarat, India",
            city: undefined
          });
        }
        this.setState({
          addresses: defaultAddress
        });
      }
      if (!required) {
        return;
      }
      if (name === "confirm_password" || name === "re-enter_password") {
        this.password[name] = "";
        return;
      }

      this.formData[name] = defaultValue || undefined;
    }
  }

  inputChange = e => {
    const newState = Object.assign({}, this.state);
    const { name } = this.props;
    newState.userInfo[name] = e.target.value;
    this.setState(newState);
    if (!e.target.required) {
      this.formData[name] = e.target.value;
      return;
    }
    this.updateValidator(
      this.props.type,
      e.target.value,
      e.target.min || 0,
      this.props.name
    );
  };

  onSubmit = () => {
    var status = true;
    for (var key in this.formData) {
      if (!this.formData[key]) {
        status = false;
      }
    }
    this.addressArray.forEach(item => {
      for (var key in item) {
        if (!item[key]) {
          status = false;
        }
      }
    });
    if (
      this.formData["new_password"] &&
      this.password["confirm_password"] !== this.formData["new_password"]
    ) {
      this.setState({ error: "password not matched" });
      return;
    }
    if (
      this.formData["password"] &&
      this.password["confirm_password"] &&
      this.password["confirm_password"] !== this.formData["password"]
    ) {
      this.setState({ error: "password not matched" });
      return;
    }
    if (status) {
      Object.keys(this.validator).forEach(fieldName => {
        this.validator[fieldName].errors = [];
        this.validator[fieldName].state = "";
        this.validator[fieldName].valid = false;
      });
      this.setState({ error: undefined });
      if (this.addressArray.length > 0) {
        this.formData["address"] = this.addressArray;
      }
      this.props.formSubmit(formData);
      return;
    }
    this.setState({
      error: "Please Check all Fields",
      submit: true
    });
  };

  updateValidator(fieldName, value, min, name) {
    this.validator[fieldName].errors = [];
    this.validator[fieldName].state = value;
    this.validator[fieldName].valid = true;
    this.validator[fieldName].rules.forEach(rule => {
      if (rule.test instanceof RegExp) {
        if (!rule.test.test(value, min)) {
          this.validator[fieldName].errors.push(rule.message);
          this.validator[fieldName].valid = false;
        }
      } else if (typeof rule.test === "function") {
        if (!rule.test(value, min)) {
          this.validator[fieldName].errors.push(
            this.props.message || rule.message
          );
          this.validator[fieldName].valid = false;
        }
      }
    });
    this.updatedData(fieldName, name, value);
  }

  updatedData = (fieldName, name, value) => {
    let key = name;
    if (name === "confirm_password") {
      this.password[name] = value;
      return;
    }
    if (!this.validator[fieldName].valid) {
      this.formData[key] = "";
      return;
    }
    this.formData[name] = value;
  };

  displayValidationErrors(fieldName) {
    const validator = this.validator[fieldName];
    const result = "";
    if (validator && !validator.valid) {
      const errors = validator.errors.map((info, index) => {
        return (
          <span className="validationText" key={index}>
            * {info}
          </span>
        );
      });
      return <div className="validationText">{errors}</div>;
    }
    return result;
  }

  onEventChange = e => {
    this.formData[e.target.name] = e.target.value;
  };

  addAddress = () => {
    this.addressArray.push({
      address: undefined,
      pin_code: undefined,
      state: "Gujarat, India",
      city: undefined
    });
    this.setState({
      addresses: [...this.state.addresses, ""]
    });
  };

  removeAddress = async (e, index, address) => {
    if (address) {
      await new Api().put(`/remove/address/${address.id}`);
    }
    const { addresses } = this.state;
    const removeAddress = addresses.pop();
    this.addressArray.splice(index, 1);
    this.setState({
      addAddress: removeAddress
    });
  };

  addressChange = (e, index) => {
    this.addressArray[index].address = e.target.value;
  };

  onStateChange = (e, index) => {
    this.addressArray[index].state = e.target.value;
  };

  onPinCodeChange = (e, index) => {
    this.addressArray[index].pin_code = e.target.value;
  };

  onCityChange = (e, index) => {
    this.addressArray[index].city = e.target.value;
  };

  renderSwitch(param) {
    const {
      type,
      label,
      placeholder,
      defaultValue,
      name,
      minValue,
      message,
      cols,
      rows,
      required,
      className
    } = this.props;
    const { addresses } = this.state;
    const listItems = address.map((link, key) => (
      <option key={key}>{link.country}</option>
    ));
    switch (param) {
      case "text":
      case "password":
        return (
          <div>
            <label htmlFor={name}>
              <b>{label}</b>
            </label>
            <input
              type={type}
              placeholder={placeholder}
              name={name}
              min={minValue}
              defaultValue={defaultValue}
              className="inputTag"
              message={message}
              autoComplete="off"
              onChange={e => this.inputChange(e)}
              required={required}
            />
          </div>
        );
      case "date":
        return (
          <div>
            <label htmlFor={name}>
              <b>{label}</b>
            </label>
            <input
              type="date"
              className="inputTag"
              required={required}
              name={name}
              message={message}
              defaultValue={defaultValue}
              onChange={e => this.onEventChange(e)}
            />
          </div>
        );
      case "number":
        return (
          <div>
            <label htmlFor={name}>
              <b>{label}</b>
            </label>
            <input
              type={type}
              className={className}
              placeholder={placeholder}
              min={minValue}
              defaultValue={defaultValue}
              onChange={e => this.inputChange(e)}
              required={required}
            />
          </div>
        );
      case "submit":
        return (
          <button
            type={type}
            className={className}
            onClick={() => this.onSubmit()}
          >
            {name}
          </button>
        );
      case "select":
        return (
          <select
            name={name}
            className={className}
            placeholder={placeholder}
            onChange={e => this.onEventChange(e)}
          >
            {listItems}
          </select>
        );
      case "textarea":
        return (
          <div>
            <label htmlFor="address">
              <b>Address</b>
            </label>
            <textarea
              cols={cols}
              rows={rows}
              name={name}
              className="inputTag"
              placeholder={placeholder}
              onChange={e => this.inputChange(e)}
              required={required}
            />
          </div>
        );
      case "add_address":
        return (
          <div>
            <button className={className} onClick={e => this.addAddress(e)}>
              Add Address
            </button>
            <br />
            {addresses.map((address, index) => {
              return (
                <div key={index}>
                  <br />
                  <br />
                  <label>Address {index + 1}</label>
                  {this.state.addresses.length > 1 && (
                    <span
                      className="icon"
                      onClick={e => this.removeAddress(e, index, address)}
                    >
                      <i className="fa fa-minus-circle" aria-hidden="true"></i>
                    </span>
                  )}
                  <br />
                  <textarea
                    className="inputTag"
                    defaultValue={address.address}
                    onChange={e => this.addressChange(e, index)}
                  />
                  <input
                    type="text"
                    className="inputTag"
                    defaultValue={address.city}
                    onChange={e => this.onCityChange(e, index)}
                    placeholder="Enter Your City"
                  />
                  <br />
                  <select
                    className="address"
                    placeholder="state"
                    defaultValue={address.state}
                    onChange={e => this.onStateChange(e, index)}
                  >
                    {listItems}
                  </select>
                  &nbsp;&nbsp;&nbsp;&nbsp;
                  <input
                    type="number"
                    className="address"
                    placeholder="Pin code"
                    defaultValue={address.pin_code}
                    onChange={e => this.onPinCodeChange(e, index)}
                  />
                  <br />
                </div>
              );
            })}
          </div>
        );

      default:
        return;
    }
  }

  render() {
    const { type } = this.props;
    const { error } = this.state;
    return (
      <div>
        {this.renderSwitch(type)}
        <div className="validationText">{error}</div>
        {this.displayValidationErrors(type)}
      </div>
    );
  }
}
