const validator = {
  text: {
    rules: [
      // {
      //   test: /^[a-z0-9_]+$/,
      //   message:
      //     "Field must contain only alphabets-numeric lowercase characters"
      // },
      {
        test: (value, min) => {
          return value.length > min;
        },
        message: "Text must be longer than two characters"
      }
    ],
    errors: [],
    valid: false,
    state: ""
  },
  password: {
    rules: [
      {
        test: value => {
          return value.length >= 6;
        },
        message: "Password must not be shorter than 6 characters"
      }
    ],
    errors: [],
    valid: false,
    state: ""
  },
  textarea: {
    rules: [
      {
        test: (value, min) => {
          return value.length >= min;
        },
        message: "text must not be shorter than 10 characters"
      }
    ],
    errors: [],
    valid: false,
    state: ""
  },
  number: {
    rules: [
      {
        test: (value, min) => {
          return value > min;
        },
        message: "text must be positive"
      }
    ],
    errors: [],
    valid: false,
    state: ""
  }
};

const formData = {};
const password = {};
const addressArray = [];

export { validator, formData, password, addressArray };
