import styled from "styled-components";

const Form = styled.div`
  .form {
    background-color: rgb(235, 235, 235);
    border-radius: 6px;
    height: ${props => props.height || "400px"};
    margin: ${props => props.margin || "80px auto 120px"};
    width: ${props => props.width || "450px"};
    font-family: "Niramit", sans-serif;
    font-size: 14px;
    box-shadow: ${props =>
      props.shadow ||
      "0 6px 6px -3px rgba(0, 0, 0, 0.2), 0 10px 14px 1px rgba(0, 0, 0, 0.14), 0 4px 18px 3px rgba(0, 0, 0, 0.12) !important"};
  }

  .inputTag {
    width: ${props => props.inputWidth || "100%"};
    padding: ${props => props.inputPadding || "12px 20px"};
    margin: ${props => props.inputMargin || "10px 0 0 0"};
    border-radius: 10px;
    display: inline-block;
    border: 1px solid #a29999;
    box-sizing: border-box;
    font-size: 14px;
    font-family: "Niramit", sans-serif;
  }

  .address {
    width: ${props => props.inputWidth || "48%"};
    padding: ${props => props.inputPadding || "12px 20px"};
    margin: ${props => props.inputMargin || "19px 0 0 4px"};
    border-radius: 15px;
    display: inline-block;
    border: 1px solid #a29999;
    box-sizing: border-box;
    font-size: 14px;
    font-family: "Niramit", sans-serif;
    outline: none;
  }

  .inputTag:focus {
    outline: none;
  }

  .container {
    padding: 19px;
  }

  .center {
    text-align: center;
  }

  .validationText {
    color: red;
    font-family: "Niramit", sans-serif;
  }
  button {
    background-color: ${props => props.bgColor || "#4caf50"};
    color: white;
    padding: 14px 20px;
    margin: ${props => props.btnMargin || "8px 0"};
    border: none;
    border-radius: 25px;
    cursor: pointer;
    text-align: center;
    width: ${props => props.btnWidth || "100%"};
    float: ${props => props.btnFloat || "right"};
    font-family: "Niramit", sans-serif;
  }

  button:hover {
    opacity: 0.8;
  }

  .icon {
    float: right;
    margin: 0 10px;
    color: red;
    cursor: pointer;
  }
  button:focus {
    outline: none;
  }
  .dangerBtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
    float: ${props => props.btnFloat || "left"};
  }

  .primaryBtn {
    width: ${props => props.btnWidth || "auto"};
    padding: 10px 18px;
    background-color: #241d3b;
  }

  @media screen and (max-width: 511px) {
    .dangerBtn {
      float: none;
      width: 100%;
    }
    .primaryBtn {
      float: none;
      width: 100%;
    }
  }

  @media screen and (max-width: 511px) {
    .form {
      background-color: rgb(235, 235, 235);
      border: 1px solid #42464b;
      border-radius: 6px;
      margin: 80px 8px 0 8px;
      width: auto;
      height: auto;
    }
    .inputTag {
      margin-left: auto;
    }
  }
`;

export default Form;
