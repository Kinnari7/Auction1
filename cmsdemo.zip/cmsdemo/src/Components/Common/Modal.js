import React from "react";
import Input from "../Common/Validation";
import Api from "../../Api/Api";
import Notification from "../Common/Toast/Toast";

export default class Modal extends React.Component {
  state = {
    toast: undefined
  };
  onSubmit = async payload => {
    const response = await new Api().put(`/edit`, payload);
    if (response) {
      this.setState(
        {
          toast: response.status.MESSAGE
        },
        () => {
          if (!this.props.profile) {
            setTimeout(() => {
              this.props.openModal();
            }, 2000);
          }
        }
      );
    }
  };

  timeOut = () => {
    this.setState({
      toast: undefined
    });
  };

  render() {
    const data = this.props.editUserData && this.props.editUserData;
    const { toast } = this.state;
    return (
      <div>
        <div className="form">
          <div className="container">
            {!this.props.profile && (
              <div>
                <span
                  className="closeBtn"
                  onClick={e => this.props.openModal(e)}
                >
                  ×
                </span>
                <br />
                <br />
              </div>
            )}

            <Input
              type="text"
              label="First Name"
              placeholder="Enter First Name"
              name="first_name"
              required={true}
              minValue={2}
              defaultValue={data && data.first_name}
              message="First Name must be grater than 2 Characters"
            />
            <br />
            <Input
              type="text"
              label="Last Name"
              placeholder="Enter Last Name"
              name="last_name"
              required={true}
              minValue={2}
              defaultValue={data && data.last_name}
              message="First Name must be grater than 2 Characters"
            />
            <br />
            <Input
              type="date"
              label="Date of Birth"
              name="dob"
              required={true}
              defaultValue={data && data.dob}
              message="Please select date"
            />

            <Input
              type="add_address"
              className="primaryBtn"
              defaultValue={data && data.userAddress}
            />
            <br />

            <Input
              type="number"
              label="Phone Number"
              placeholder="Enter Your Phone Number"
              name="phone_number"
              required={true}
              className="inputTag"
              minValue={10}
              defaultValue={data && data.phone_number}
              message="Please enter valid Phone Number"
            />
            <br />
            <br />
            <Input
              type="submit"
              className="primaryBtn"
              name="Update"
              formSubmit={this.onSubmit}
            />
            {this.state.toast && (
              <Notification message={toast} timeOut={this.timeOut} />
            )}
            <br />
            <br />
          </div>
        </div>
      </div>
    );
  }
}
