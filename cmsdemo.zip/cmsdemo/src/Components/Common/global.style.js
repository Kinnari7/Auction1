import styled from "styled-components";

const Global = styled.div`
  .info {
    margin-left: ${props => props.ml || "190px"};
    margin-top: ${props => props.mt || "0px"};
  }

  @media screen and (max-width: 511px) {
    .info {
      margin-left: 0px;
      margin-top: ${props => props.mt || "0px"};
    }
  }
`;


export default Global;
