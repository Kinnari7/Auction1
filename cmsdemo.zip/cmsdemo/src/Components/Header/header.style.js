import styled from "styled-components";

const headerWrapper = styled.div`
  .navbar {
    margin-left: 190px;
    overflow: hidden;
    background-color: rgb(235, 235, 235);
    font-family: "Niramit", sans-serif;
    box-shadow: ${props =>
      props.shadow ||
      "0 6px 6px -3px rgba(0, 0, 0, 0.1), 0 10px 14px 1px rgba(0, 0, 0, 0.14), 0 4px 18px 3px rgba(0, 0, 0, 0.12) !important"};
  }

  .navbar .btn {
    float: left;
    display: block;
    color: rgb(235, 235, 235);
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 16px;
  }

  button {
    background-color: Transparent;
    background-repeat: no-repeat;
    border: none;
    cursor: pointer;
    overflow: hidden;
    outline: none;
  }

  .toggle {
    visibility: hidden;
    color: #000000;
  }

  .sidebar .active {
    color: white;
  }
  .dropDown {
    float: right;
    overflow: hidden;
  }

  .dropDown .dropBtn {
    font-size: 24px;
    border: none;
    outline: none;
    color: #000000;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
  }

  .navbar a:hover,
  .dropDown:hover .dropBtn {
    background-color: C0C0C0;
  }

  .dropDown-content {
    right: 0;
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
    z-index: 1;
    font-size: 16px;
  }

  .dropDown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
  }

  .dropDown-content a:hover {
    background-color: #ddd;
  }

  .dropDown:hover .dropDown-content {
    display: block;
  }

  @media screen and (max-width: 511px) {
    .header a {
      float: none;
      display: block;
      text-align: left;
    }
    .toggle {
      visibility: visible;
      cursor: pointer;
      font-size: 25px;
    }
    .header-right {
      float: none;
    }
    .navbar {
      margin: auto;
    }
    .sidebar {
      height: 100%;
      width: 180px;
      position: fixed;
      z-index: 1;
      top: 0;
      left: 0;
      background-color: #241d3b;
      overflow-x: hidden;
      transition: 0.9s;
      padding-top: 40px;
    }
    .sidebar a,
    span {
      padding: 8px 8px 8px 7px;
      text-decoration: none;
      font-size: 25px;
      color: #818181;
      display: block;
      transition: 0.9s;
    }
    .sidebar .closeBtn {
      position: absolute;
      top: 0;
      right: 25px;
      font-size: 36px;
      margin-left: 50px;
    }
  }
  @media screen and (min-width: 512px) {
    .sidebar {
      height: 100%;
      width: 0;
      position: absolute;
      z-index: 1;
      top: 0;
      left: 0;
      background-color: #111;
      overflow-x: hidden;
      transition: 0.9s;
      padding-top: 60px;
    }
    .sidebar a,
    span {
      padding: 0px 0px 0px 0px;
      text-decoration: none;
      font-size: 25px;
      color: #818181;
      display: none;
      transition: 0.3s;
    }
    .sidebar .closeBtn {
      position: absolute;
      visibility: hidden;
    }
  }
`;

export default headerWrapper;
