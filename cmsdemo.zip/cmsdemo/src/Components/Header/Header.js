import React from "react";
import HeaderWrapper from "./header.style";
import { Link } from "react-router-dom";
import Api from "../../Api/Api";
export default class Header extends React.Component {
  constructor() {
    super();
    this.state = {
      sidebar: false
    };
    this.signOut = this.signOut.bind(this);
  }

  openSidebar = () => {
    this.setState({
      sidebar: true
    });
  };

  closeSidebar = () => {
    this.setState({
      sidebar: false
    });
  };

  async signOut() {
    const response = await new Api().get(`/logout`);
    if (response && response.status.CODE === 204) {
      localStorage.clear();
    }
  }
  render() {
    return (
      <HeaderWrapper>
        <div className="navbar">
          <button className={`btn toggle `} onClick={() => this.openSidebar()}>
            <i className="fa fa-bars toggle" aria-hidden="true" />
          </button>
          {this.state.sidebar && (
            <div className="sidebar">
              <button>
                <span className="closeBtn" onClick={() => this.closeSidebar()}>
                  ×
                </span>
              </button>

              <span>
                <Link
                  to="/dashboard"
                  className={
                    window.location.pathname === "/dashboard" ? "active" : ""
                  }
                  onClick={() => this.closeSidebar()}
                >
                  <i className="fa fa-tachometer" aria-hidden="true">
                    &nbsp; Dashboard
                  </i>
                </Link>
              </span>
              <span>
                <Link
                  to="/users-info"
                  className={
                    window.location.pathname === "/users-info" ? "active" : ""
                  }
                  onClick={() => this.closeSidebar()}
                >
                  <i className="fa fa-users" aria-hidden="true">
                    &nbsp; Users
                  </i>
                </Link>
              </span>
            </div>
          )}
          <div className="dropDown">
            <button className="dropBtn">
              <i className="fa fa-cog" aria-hidden="true">
                &nbsp;Settings
              </i>
            </button>
            <div className="dropDown-content">
              <Link to="/profile">Profile</Link>
              <Link to="/change-password">Change Password</Link>
              <Link to="" onClick={() => this.signOut()}>
                Sign Out
              </Link>
            </div>
          </div>
        </div>
      </HeaderWrapper>
    );
  }
}
