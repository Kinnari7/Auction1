import React from "react";
import RegisterWrapper from "./register.style";
import { Redirect } from "react-router-dom";
import Form from "../Common/form.style";
import Input from "../Common/Validation";
import Api from "../../Api/Api";
import Notification from "../Common/Toast/Toast";

export default class Register extends React.Component {
  state = {
    backToLogIn: false,
    toast: undefined
  };

  componentDidMount() {
    localStorage.clear();
  }

  onSubmit = async payload => {
    const response = await new Api().post(`/register`, payload);
    if (response) {
      this.setState({
        toast: response.status.MESSAGE
      });
    }
  };

  timeOut = () => {
    this.setState({
      toast: undefined
    });
  };

  /* redirect to login page on cancel*/

  redirectToLogIn = () => {
    this.setState({
      backToLogIn: true
    });
  };

  render() {
    const { backToLogIn, toast } = this.state;
    if (backToLogIn) {
      return <Redirect to="/login" />;
    }
    return (
      <RegisterWrapper>
        <Form
          height="auto"
          width="450px"
          margin="40px auto 1px"
          inputMargin="9px 0"
          inputPadding="10px 20px"
        >
          <div className="info">
            <div className="form">
              <div className="container">
                <span className="back" onClick={() => this.redirectToLogIn()}>
                  <i className="fa fa-arrow-circle-left"></i>
                </span>
                <br />
                <br />
                <Input
                  type="text"
                  label="First Name"
                  placeholder="Enter First Name"
                  name="first_name"
                  required={true}
                  minValue={2}
                  message="First Name must be grater than 2 Characters"
                />
                <Input
                  type="text"
                  label="Last Name"
                  placeholder="Enter Last Name"
                  name="last_name"
                  required={true}
                  minValue={2}
                  message="First Name must be grater than 2 Characters"
                />
                <Input
                  type="text"
                  label="Email"
                  placeholder="Enter Your Email"
                  name="email"
                  required={true}
                  message="Please enter valid email"
                />
                <Input
                  type="date"
                  label="Date of Birth"
                  name="dob"
                  required={true}
                  message="Please select date"
                />
                <Input type="add_address" className="primaryBtn" />
                <Input
                  type="number"
                  label="Phone Number"
                  placeholder="Enter Your Phone Number"
                  name="phone_number"
                  required={true}
                  className="inputTag"
                  minValue={10}
                  message="Please enter valid Phone Number"
                />
                <Input
                  type="password"
                  label="Password"
                  placeholder="Enter Password"
                  name="password"
                  required={true}
                />
                <Input
                  type="password"
                  label="Confirm Password"
                  placeholder="Re-Enter Password"
                  name="confirm_password"
                  required={true}
                />
                <br />
                <Input
                  type="submit"
                  className="primaryBtn"
                  name="Update"
                  formSubmit={this.onSubmit}
                />
                {toast && (
                  <Notification message={toast} timeOut={this.timeOut} />
                )}
                <br />
                <br />
              </div>
            </div>
          </div>
        </Form>
      </RegisterWrapper>
    );
  }
}
