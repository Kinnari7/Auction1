import styled from "styled-components";

const RegisterWrapper = styled.div`
  overflow: hidden;

  span.psw {
    float: right;
    padding-top: 16px;
  }

  span.register {
    text-align: center;
    padding-top: 16px;
  }

  .back {
    color:  #241d3b;
    font-size: 25px;
    float: left;
    cursor: pointer;
  }
  @media screen and (max-width: 511px) {
    span.psw {
      display: block;
      float: none;
    }
  }
`;

export default RegisterWrapper;
