import React from "react";
import Global from "../Common/global.style";
import Form from "../Common/form.style";
import Input from "../Common/Validation";
import Api from "../../Api/Api";
import Notification from "../Common/Toast/Toast";

export default class ChangePassword extends React.Component {
  state = {
    toast: undefined
  };
  onSubmit = async payload => {
    const response = await new Api().put(`change_password`, payload);
    if (response) {
      this.setState({
        toast: response.status.MESSAGE
      });
    }
  };

  timeOut = () => {
    this.setState({
      toast: undefined
    });
  };

  render() {
    const { toast } = this.state;
    return (
      <Global>
        <Form
          height="auto"
          width="350px"
          inputMargin="15px 0"
          inputPadding="12px 20px"
        >
          <div className="info">
            <div className="form">
              <div className="container">
                <Input
                  type="password"
                  label="Old Password"
                  placeholder="Enter Old Password"
                  name="old_password"
                  required={true}
                  message="Password must not be shorter than 6 characters"
                />

                <Input
                  type="password"
                  label="New Password"
                  placeholder="Enter New Password"
                  name="new_password"
                  required={true}
                />

                <Input
                  type="password"
                  label="Confirm Password"
                  placeholder="Re-Enter Password"
                  name="confirm_password"
                  required={true}
                />

                <Input
                  type="submit"
                  className="primaryBtn"
                  name="Change Password"
                  formSubmit={this.onSubmit}
                />
                {toast && (
                  <Notification message={toast} timeOut={this.timeOut} />
                )}
                <br />
                <br />
                <br />
              </div>
            </div>
          </div>
        </Form>
      </Global>
    );
  }
}
