import React from "react";
import UserWrapper from "./user.style";
import Global from "../Common/global.style";
import Form from "../Common/form.style";
import Modal from "../Common/Modal";
import Api from "../../Api/Api";
import Input from "../Common/Validation";
import Notification from "../Common/Toast/Toast";

export default class UserInfo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      filteredData: [],
      data: undefined,
      deleteUser: undefined,
      searchInput: "",
      editUserData: undefined,
      openModal: false,
      confirmModal: undefined,
      addUserModal: false,
      toast: undefined
    };
  }

  async componentDidMount() {
    const response = await new Api().get(`/list`);
    this.setState({
      data: response.data
    });
  }

  async componentDidUpdate() {
    const { data } = this.state;
    const response = await new Api().get(`/list`);
    if (response.data.length !== data.length) {
      this.setState({
        data: response.data
      });
    }
  }

  onSubmit = async payload => {
    const { addUserModal } = this.state;
    const response = await new Api().post(`/add_user`, payload);
    if (response) {
      this.setState({
        toast: response.status.MESSAGE,
        addUserModal: !addUserModal
      });
    }
  };

  timeOut = () => {
    this.setState({
      toast: undefined
    });
  };

  handleChange = event => {
    this.setState({ searchInput: event.target.value }, () =>
      this.globalSearch()
    );
  };

  globalSearch = () => {
    const { searchInput, data } = this.state;
    const filteredData = data.filter(value => {
      return (
        value.first_name.toLowerCase().includes(searchInput.toLowerCase()) ||
        value.last_name.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    this.setState({
      filteredData: filteredData
    });
  };

  openEditModal = data => {
    const modal = this.state.openModal;
    this.setState(
      {
        openModal: !modal
      },
      () => this.setFieldsValue(data)
    );
  };

  confirmDeleteModal = item => {
    const modal = this.state.confirmModal;
    this.setState({
      deleteUser: item,
      confirmModal: !modal
    });
  };

  setFieldsValue = user_info => {
    this.setState({
      editUserData: user_info
    });
  };

  addUser = () => {
    const { addUserModal } = this.state;
    this.setState({
      addUserModal: !addUserModal
    });
  };

  deleteUserData = async () => {
    const { deleteUser, confirmModal } = this.state;
    const response = await new Api().delete(`/delete/${deleteUser.id}`);
    if (response) {
      this.setState({
        toast: response.status.MESSAGE,
        confirmModal: !confirmModal
      });
    }
  };

  render() {
    const {
      searchInput,
      filteredData,
      openModal,
      editUserData,
      confirmModal,
      addUserModal,
      toast
    } = this.state;
    const data = searchInput ? filteredData : this.state.data;
    return (
      <Global mt="130px">
        <UserWrapper>
          <Form
            inputWidth="30%"
            inputMargin="0 auto 0 70px"
            btnMargin="30px auto 0 auto"
          >
            {toast && <Notification message={toast} timeOut={this.timeOut} />}
            {this.state.data && (
              <div className="info">
                {confirmModal && (
                  <div className="overlay">
                    <div className="modal">
                      <Form
                        height="130px"
                        width="270px"
                        inputMargin="19px 0"
                        inputPadding="12px 20px"
                        btnFloat="right"
                        btnMargin="20px 0"
                      >
                        <div className="form">
                          <div className="container">
                            <span
                              className="closeBtn"
                              onClick={() => this.confirmDeleteModal()}
                            >
                              ×
                            </span>
                            <br />
                            <label>Are you sure Want to Delete ?</label>

                            <button
                              type="submit"
                              className="dangerBtn"
                              onClick={() => this.deleteUserData()}
                            >
                              Delete
                            </button>
                          </div>
                        </div>
                      </Form>
                    </div>
                  </div>
                )}
                {openModal && editUserData && editUserData.userAddress && (
                  <UserWrapper>
                    <div className="overlay">
                      <div className="modal">
                        <Form
                          height="auto"
                          width="50%"
                          inputMargin="3px 0"
                          inputPadding="11px 20px"
                          shadow="0 6px 6px -3px rgba(0, 0, 0, 0.2), 0 10px 14px 1px rgba(0, 0, 0, 0.14), 0 4px 18px 3px rgba(0, 0, 0, 0.12) !important"
                          margin="20px auto 20px"
                        >
                          <Modal
                            openModal={this.openEditModal}
                            updateData={this.updateData}
                            editUserData={editUserData}
                          />
                        </Form>
                      </div>
                    </div>
                  </UserWrapper>
                )}
                {addUserModal && (
                  <div className="overlay">
                    <div className="modal">
                      <Form
                        height="auto"
                        width="50%"
                        inputMargin="3px 0"
                        inputPadding="11px 20px"
                        shadow="0 6px 6px -3px rgba(0, 0, 0, 0.2), 0 10px 14px 1px rgba(0, 0, 0, 0.14), 0 4px 18px 3px rgba(0, 0, 0, 0.12) !important"
                        margin="20px auto 20px"
                      >
                        <div className="form">
                          <div className="container">
                            <span
                              className="closeBtn"
                              onClick={() => this.addUser()}
                            >
                              ×
                            </span>
                            <br />
                            <br />
                            <Input
                              type="text"
                              label="First Name"
                              placeholder="Enter First Name"
                              name="first_name"
                              required={true}
                              minValue={2}
                              message="First Name must be grater than 2 Characters"
                            />
                            <Input
                              type="text"
                              label="Last Name"
                              placeholder="Enter Last Name"
                              name="last_name"
                              required={true}
                              minValue={2}
                              message="First Name must be grater than 2 Characters"
                            />
                            <Input
                              type="text"
                              label="Email"
                              placeholder="Enter Your Email"
                              name="email"
                              required={true}
                              message="Please enter valid email"
                            />
                            <Input
                              type="date"
                              label="Date of Birth"
                              name="dob"
                              required={true}
                              message="Please select date"
                            />
                            <Input type="add_address" className="primaryBtn" />
                            <Input
                              type="number"
                              label="Phone Number"
                              placeholder="Enter Your Phone Number"
                              name="phone_number"
                              required={true}
                              className="inputTag"
                              minValue={10}
                              message="Please enter valid Phone Number"
                            />
                            <Input
                              type="password"
                              label="Password"
                              placeholder="Enter Password"
                              name="password"
                              required={true}
                            />
                            <Input
                              type="password"
                              label="Confirm Password"
                              placeholder="Re-Enter Password"
                              name="confirm_password"
                              required={true}
                            />
                            <br />
                            <Input
                              type="submit"
                              className="primaryBtn"
                              name="Update"
                              formSubmit={this.onSubmit}
                            />
                            <br />
                            <br />
                            <br />
                          </div>
                        </div>
                      </Form>
                    </div>
                  </div>
                )}
                <div>
                  <input
                    type="text"
                    name="searchInput"
                    value={this.state.searchInput || ""}
                    onChange={this.handleChange}
                    className="inputTag"
                    placeholder="Search"
                  />
                  <button
                    type="submit"
                    className="add"
                    onClick={() => this.addUser()}
                  >
                    Add
                  </button>
                </div>
                <br />
                <table>
                  <tbody>
                    <tr>
                      <th>First Name</th>
                      <th>Last Name</th>
                      <th>Email</th>
                      <th>Birth Date</th>
                      <th>Address</th>
                      <th>City</th>
                      <th>Pin Code</th>
                      <th>State</th>
                      <th>Phone Number</th>
                      <th>Actions</th>
                    </tr>

                    {data.map((item, key) => {
                      return (
                        <tr key={key}>
                          <td>
                            <label>{item.first_name}</label>
                          </td>
                          <td>{item.last_name}</td>
                          <td>{item.email}</td>
                          <td>{item.dob}</td>
                          <td>{item.userAddress[0].address}</td>
                          <td>{item.userAddress[0].city}</td>
                          <td>{item.userAddress[0].pin_code}</td>
                          <td>{item.userAddress[0].state}</td>
                          <td>{item.phone_number}</td>
                          <td>
                            <i
                              className="fa fa-pencil size"
                              aria-hidden="true"
                              onClick={() => this.openEditModal(item)}
                            ></i>
                            <i
                              className="fa fa-trash size"
                              aria-hidden="true"
                              onClick={() => this.confirmDeleteModal(item)}
                            ></i>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </Form>
        </UserWrapper>
      </Global>
    );
  }
}
