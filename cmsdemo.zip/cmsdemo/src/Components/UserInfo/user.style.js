import styled from "styled-components";

const UserWrapper = styled.div`
  overflow-x: auto;

  table {
    border-spacing: 0;
    width: 90%;
    border: 1px solid #ddd;
    margin: 0 auto 0 70px;
    font-family: "Niramit", sans-serif;
    border-radius: 10px;
  }

  th {
    background-color: #241d3b;
    color: white;
    font-size: 14px;
    padding: 8px;
    border-radius: 10px;
  }

  tr:nth-child(even) {
    background-color: #dddddd;
  }

  td {
    text-align: center;
    padding: 8px;
    font-size: 16px;
  }

  table,
  td,
  th {
    border: 3px solid #ddd;
  }

  tr:hover {
    background-color: #ddd;
  }
  .size {
    font-size: 18px;
    padding: 0 10px 0 10px;
  }

  .size:hover {
    cursor: pointer;
  }

  modal {
    display: none;
    position: relative;
    z-index: 1;
    padding-top: 2px;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.6);
  }
  .overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 10;
    overflow-y: scroll;
    background-color: rgba(0, 0, 0, 0.6);
  }

  .closeBtn {
    float: right;
    font-size: 25px;
    color: red;
  }

  .closeBtn:hover,
  .closeBtn:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
  }

  .add {
    margin: 3px 70px 0 auto;
    border-radius: 25px;
    width: auto;
    color: white;
    padding: 12px 20px;
    background-color: #241d3b;
    border: none;
    cursor: pointer;
    float: right;
    font-family: "Niramit", sans-serif;
  }
  .add:hover {
    opacity: 0.8;
  }

  .add:focus {
    outline: none;
  }

  @media screen and (max-width: 511px) {
    table {
      margin-left: 0px;
      margin-top: ${props => props.mt || "0px"};
    }

    .overlay {
      height: auto;
    }
    .overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 10;
      background-color: rgba(0, 0, 0, 0.6);
    }
  }
`;

export default UserWrapper;
