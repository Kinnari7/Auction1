export const data = [
  {
    first_name: "Arpit",
    last_name: "vyas",
    email: "arpit.vyas@openxcellinc.com",
    dob: "1998-03-30",
    address: "G'nagar",
    city: "Dehgam",
    phone_number: "7046812812"
  },
  {
    first_name: "Brijesh",
    last_name: "vyas",
    email: "arpit.vyas@openxcellinc.com",
    dob: "30-03-1998",
    address: "G'nagar",
    city: "Dehgam",
    phone_number: "7046812812"
  },
  {
    first_name: "dishant",
    last_name: "vyas",
    email: "arpit.vyas@openxcellinc.com",
    dob: "30-03-1998",
    address: "G'nagar",
    city: "Dehgam",
    phone_number: "7046812812"
  },
  {
    first_name: "atrik",
    last_name: "vyas",
    email: "arpit.vyas@openxcellinc.com",
    dob: "30-03-1998",
    address: "G'nagar",
    city: "Dehgam",
    phone_number: "7046812812"
  },
  {
    first_name: "amit",
    last_name: "vyas",
    email: "arpit.vyas@openxcellinc.com",
    dob: "30-03-1998",
    address: "G'nagar",
    city: "Dehgam",
    phone_number: "7046812812"
  },
  {
    first_name: "aamin",
    last_name: "vyas",
    email: "arpit.vyas@openxcellinc.com",
    dob: "30-03-1998",
    address: "G'nagar",
    city: "Dehgam",
    phone_number: "7046812812"
  }
];

export const address = [
  {
    country: "Gujarat , India"
  },
  {
    country: "Rajasthan, India"
  },
  {
    country: "Delhi,India"
  }
];

