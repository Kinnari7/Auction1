import React from "react";
import Global from "../Common/global.style";
import Form from "../Common/form.style";

export default class Default extends React.Component {
  render() {
    return (
      <Global>
        <Form
          height="auto"
          width="50%"
          inputMargin="8px 0"
          inputPadding="9px 20px"
          shadow="0 6px 6px -3px rgba(0, 0, 0, 0.2), 0 10px 14px 1px rgba(0, 0, 0, 0.14), 0 4px 18px 3px rgba(0, 0, 0, 0.12) !important"
          margin="40px auto 20px"
        >
          <div className="info">
            <div className="form">
              <div className="container center">Page Not Found</div>
            </div>
          </div>
        </Form>
      </Global>
    );
  }
}
