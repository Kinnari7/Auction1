import React from "react";
import Route from "./Routes/Routes";
import { BrowserRouter as Router } from "react-router-dom";

function App() {
  return (
    <Router>
      <Route />
    </Router>
  );
}

export default App;
